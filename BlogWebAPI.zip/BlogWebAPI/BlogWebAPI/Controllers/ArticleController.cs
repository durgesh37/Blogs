﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BlogWebAPI.Interface;
using BlogWebAPI.Repository;
using BlogWebAPI.Models;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using System.Web.Mvc;
using BlogWebAPI.Utilities;

namespace BlogWebAPI.Controllers
{
    
    public class ArticleController : ApiController
    {
        private IArticle articleRepository = new ArticleRepository();
       
        public async Task<bool> Post([FromBody] Article articleModel)
        {
            try
            {
                var result = await articleRepository.InsertBlog(articleModel);
                return true;
            }
            catch(Exception ex)
            {
                Logger.log(Convert.ToString(ex));
                return false;
            }
        }

        
        public async Task<bool> Put([FromBody] Article articleModel)
        {
            try
            {
                var result = await articleRepository.UpdateBlog(articleModel);
                return true;
            }
            catch (Exception ex)
            {
                Logger.log(Convert.ToString(ex));
                return false;
            }
        }

        
        public async Task<bool> Delete([FromBody] Article articleModel)
        {
            try
            {
                var result = await articleRepository.DeleteBlog(articleModel);
                return true;
            }
            catch (Exception ex)
            {
                Logger.log(Convert.ToString(ex));
                return false;
            }
        }

        
        public async Task<List<Article>> Get(int? id)
        {
            List<Article> articleDate = new List<Article>();
            try
            {
                var result = await articleRepository.GetBlog(id);
                return result;
            }
            catch (Exception ex)
            {
                Logger.log(Convert.ToString(ex));
                return articleDate;
            }
        }
    }
}
