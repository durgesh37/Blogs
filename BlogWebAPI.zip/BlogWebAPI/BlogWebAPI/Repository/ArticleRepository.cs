﻿using BlogWebAPI.Interface;
using BlogWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using BlogWebAPI.Utilities;
namespace BlogWebAPI.Repository
{
    public class ArticleRepository : IArticle
    {

        public async Task<bool> InsertBlog(Article articleModel)
        {
            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["ArticleConnectionString"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(conStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "spAddArticle";
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ArticleCategory", articleModel.ArticleCategory);
                        cmd.Parameters.AddWithValue("@AuthorId", articleModel.AuthorId);
                        cmd.Parameters.AddWithValue("@DateCreated", articleModel.DateCreated);
                        cmd.Parameters.AddWithValue("@DateUpdated", articleModel.DateUpdated);
                        cmd.Parameters.AddWithValue("@DatePublished", articleModel.DatePublished);
                        cmd.Parameters.AddWithValue("@PageTitle", articleModel.PageTitle);
                        cmd.Parameters.AddWithValue("@IsPublished", articleModel.IsPublished);
                        cmd.Parameters.AddWithValue("@Description", articleModel.Description);

                        conn.Open();
                        int i = cmd.ExecuteNonQuery();
                        if (i > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }               
            }
            catch(Exception ex)
            {
                Logger.log(Convert.ToString(ex));
                return false;
            }
            
        }


        public async Task<bool> UpdateBlog(Article articleModel)
        {
            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["ArticleConnectionString"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(conStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "spUpdateArticle";
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ArticleId", articleModel.ArticleId);
                        cmd.Parameters.AddWithValue("@ArticleCategory", articleModel.ArticleCategory);
                        cmd.Parameters.AddWithValue("@AuthorId", articleModel.AuthorId);
                        cmd.Parameters.AddWithValue("@DateCreated", articleModel.DateCreated);
                        cmd.Parameters.AddWithValue("@DateUpdated", articleModel.DateUpdated);
                        cmd.Parameters.AddWithValue("@DatePublished", articleModel.DatePublished);
                        cmd.Parameters.AddWithValue("@PageTitle", articleModel.PageTitle);
                        cmd.Parameters.AddWithValue("@IsPublished", articleModel.IsPublished);
                        cmd.Parameters.AddWithValue("@Description", articleModel.Description);

                        conn.Open();

                        int i = cmd.ExecuteNonQuery();
                        if (i > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.log(Convert.ToString(ex));
            }

            return true;

        }

        public async Task<bool> DeleteBlog(Article articleModel)
        {
            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["ArticleConnectionString"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(conStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "spDeleteArticle";
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ArticleId", articleModel.ArticleId);

                        conn.Open();
                        int i = cmd.ExecuteNonQuery();
                        if (i > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Logger.log(Convert.ToString(ex));
                return false;
            }

            
        }

        public async Task<List<Article>> GetBlog(int? id)
        {
            List<Article> articles = new List<Article>();
            Article articleData = new Article();
            try
            {              
                string conStr = ConfigurationManager.ConnectionStrings["ArticleConnectionString"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(conStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "spGetArticle";
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@Id", id);

                        conn.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                articleData = new Article
                                {
                                    Id              =   Convert.ToInt32(dr["Id"]),
                                    ArticleId       =   Convert.ToString(dr["ArticleId"]),
                                    ArticleCategory =   Convert.ToString(dr["ArticleCategory"]),
                                    AuthorId        =   Convert.ToString(dr["AuthorId"]),
                                    DateCreated     =   Convert.ToString(dr["DateCreated"]),
                                    DateUpdated     =   Convert.ToString(dr["DateUpdated"]),
                                    DatePublished   =   Convert.ToString(dr["DatePublished"]),
                                    PageTitle       =   Convert.ToString(dr["PageTitle"]),
                                    PageContent     =   Convert.ToString(dr["PageContent"]),
                                    IsPublished     =   Convert.ToString(dr["IsPublished"]),
                                    Description     =   Convert.ToString(dr["Description"]),

                                };
                                articles.Add(articleData);
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Logger.log(Convert.ToString(ex));
            }
            return articles;

        }

    }
}