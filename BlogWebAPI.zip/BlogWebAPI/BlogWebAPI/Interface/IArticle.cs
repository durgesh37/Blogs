﻿using BlogWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace BlogWebAPI.Interface
{
    public interface IArticle
    {
        Task<bool> InsertBlog(Article articleModel);
        Task<bool> UpdateBlog(Article articleModel);
        Task<bool> DeleteBlog(Article articleModel);
        Task<List<Article>> GetBlog(int? id);
    }
}