﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
namespace BlogWebAPI.Utilities
{
    public static class Logger
    {
        public static string logfile { get; set; }
        public static void log(string p_line)
        {           
            var logfile = System.Web.Hosting.HostingEnvironment.MapPath("~/App_Data/LogFile.txt");          
            File.AppendAllText(logfile, "\n");
            File.AppendAllText(logfile, DateTime.Now.ToString());
            File.AppendAllText(logfile, "\n");
            File.AppendAllText(logfile, p_line);
            File.AppendAllText(logfile, "\n");
            File.AppendAllText(logfile, "================================================================================================================");
        }
    }
}